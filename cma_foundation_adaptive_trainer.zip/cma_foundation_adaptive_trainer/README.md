# CMA Foundation Adaptive MCQ Trainer

A full-stack starter for practicing CMA Foundation from the four uploaded ICMAI Study Notes.

## Included
- 4 separate papers/subjects
- PDF ingestion endpoint
- Topic/chapter metadata based on the uploaded study-note structure
- MCQ generation through an OpenAI-compatible API adapter
- Persistent question bank in SQLite
- Attempt tracking
- Adaptive topic weighting: weak topics receive higher selection weight
- Mistake bank
- Subject-wise accuracy
- Practice score estimate for each paper and overall
- Dashboard-ready REST API

## Subjects
- Paper 1 — Fundamentals of Business Laws and Business Communication
- Paper 2 — Fundamentals of Financial and Cost Accounting
- Paper 3 — Fundamentals of Business Mathematics and Statistics
- Paper 4 — Fundamentals of Business Economics and Management

The uploaded notes identify these as Syllabus 2022 study notes, reprinted/revised in the supplied PDFs.

## Run backend

Python 3.11+ recommended.

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Windows
# or cp .env.example .env

uvicorn app:app --reload
```

Then open http://127.0.0.1:8000/docs

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

The frontend expects the API at `http://127.0.0.1:8000`.

## AI configuration

Copy `.env.example` to `.env` and set:

- `LLM_API_KEY`
- `LLM_BASE_URL` (default is an OpenAI-compatible endpoint)
- `LLM_MODEL`

The generator is deliberately source-grounded: it sends extracted source passages and requires every generated MCQ to include a source page and a short source excerpt. If the model cannot support a question from the source, it must return `null` rather than invent it.

## Important design choice

"Every possible MCQ" cannot be guaranteed literally. The system instead builds a large, source-grounded question bank and continuously generates additional variants when a topic has insufficient coverage.

The score estimate is a practice-performance estimate, not a guarantee of the real CMA result.
