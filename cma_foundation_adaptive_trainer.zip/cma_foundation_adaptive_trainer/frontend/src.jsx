import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API="http://127.0.0.1:8000";
const names={
 paper1:"Laws & Communication",paper2:"Financial & Cost Accounting",
 paper3:"Mathematics & Statistics",paper4:"Economics & Management"
};

function App(){
 const [dash,setDash]=useState({});
 const [paper,setPaper]=useState("paper1");
 const [q,setQ]=useState(null);
 const [selected,setSelected]=useState("");
 const [result,setResult]=useState(null);
 const [stats,setStats]=useState([]);
 const [loading,setLoading]=useState(false);

 async function loadDash(){setDash(await (await fetch(API+"/api/dashboard")).json())}
 async function loadStats(p=paper){setStats(await (await fetch(API+"/api/topic-stats/"+p)).json())}
 async function next(p=paper){
   setLoading(true);setResult(null);setSelected("");
   const r=await fetch(API+"/api/question/"+p);
   setQ(r.ok?await r.json():null);setLoading(false);
 }
 useEffect(()=>{loadDash();loadStats()},[]);
 useEffect(()=>{loadStats(paper);next(paper)},[paper]);

 async function submit(){
   if(!selected||!q)return;
   const r=await fetch(API+"/api/answer",{method:"POST",headers:{"Content-Type":"application/json"},
     body:JSON.stringify({question_id:q.id,selected})});
   setResult(await r.json()); await loadDash(); await loadStats();
 }

 return <div className="app">
  <header><div><h1>CMA Foundation Adaptive Trainer</h1><p>Source-grounded MCQ practice</p></div>
   <div className="overall">{dash.overall?.estimated_score!=null?`${dash.overall.estimated_score}/400`:"—"}<small>practice estimate</small></div>
  </header>

  <section className="cards">{Object.entries(names).map(([p,n])=>
    <button className={"card "+(paper===p?"active":"")} onClick={()=>setPaper(p)} key={p}>
      <b>{n}</b><span>{dash[p]?.estimated_score!=null?`${dash[p].estimated_score}/100`:"No data"}</span>
      <small>{dash[p]?.accuracy!=null?`${dash[p].accuracy}% estimated accuracy`:"Start practicing"}</small>
    </button>)}</section>

  <main>
   <section className="quiz">
    <div className="bar"><span>{names[paper]}</span><span>{q?.module} · {q?.topic}</span></div>
    {loading?<div className="empty">Loading question…</div>:!q?<div className="empty">No questions yet. Upload notes and generate the question bank from the API.</div>:
    <>
      <h2>{q.question}</h2>
      <div className="options">{["a","b","c","d"].map(x=>
        <button disabled={!!result} className={selected===x?"chosen":""} onClick={()=>setSelected(x)} key={x}>
          <b>{x.toUpperCase()}</b>{q[x]}
        </button>)}</div>
      {!result?<button className="primary" disabled={!selected} onClick={submit}>Submit Answer</button>:
      <div className={"result "+(result.correct?"good":"bad")}>
        <b>{result.correct?"Correct":"Incorrect"}</b>
        <p>Correct answer: {result.answer?.toUpperCase()}</p>
        <p>{result.explanation}</p>
        {result.source_page&&<small>Source: study notes, page {result.source_page}</small>}
        <button className="primary" onClick={()=>next()}>Next adaptive question</button>
      </div>}
    </>}
   </section>

   <aside>
    <h3>Weak-topic radar</h3>
    {stats.length===0?<p>No attempts yet.</p>:stats.slice(0,8).map((s,i)=>
      <div className="stat" key={i}><div><b>{s.topic}</b><small>{s.module}</small></div><strong>{s.accuracy}%</strong></div>)}
   </aside>
  </main>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);
