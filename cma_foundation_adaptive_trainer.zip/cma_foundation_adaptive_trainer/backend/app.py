import os, json, math, sqlite3, random, hashlib
from pathlib import Path
from typing import Optional, List
import fitz
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()
DB = os.getenv("DATABASE_PATH", "./cma_trainer.db")
BASE_URL = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/")
API_KEY = os.getenv("LLM_API_KEY", "")
MODEL = os.getenv("LLM_MODEL", "")
ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]

SUBJECTS = {
    "paper1": {
        "name": "Fundamentals of Business Laws and Business Communication",
        "weights": {"Module 1": 0.10, "Module 2": 0.30, "Module 3": 0.20, "Module 4": 0.20, "Module 5": 0.20},
    },
    "paper2": {
        "name": "Fundamentals of Financial and Cost Accounting",
        "weights": {"Module 1": 0.30, "Module 2": 0.15, "Module 3": 0.25, "Module 4": 0.30},
    },
    "paper3": {
        "name": "Fundamentals of Business Mathematics and Statistics",
        "weights": {"Module 1": 0.15, "Module 2": 0.20, "Module 3": 0.05, "Module 4": 0.05, "Module 5": 0.15, "Module 6": 0.15, "Module 7": 0.15, "Module 8": 0.10},
    },
    "paper4": {
        "name": "Fundamentals of Business Economics and Management",
        "weights": {"Module 1": 0.15, "Module 2": 0.20, "Module 3": 0.20, "Module 4": 0.15, "Module 5": 0.30},
    },
}

app = FastAPI(title="CMA Foundation Adaptive MCQ Trainer", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=ORIGINS, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS sources(
      id INTEGER PRIMARY KEY, paper TEXT, filename TEXT, pages INTEGER, sha256 TEXT UNIQUE
    );
    CREATE TABLE IF NOT EXISTS chunks(
      id INTEGER PRIMARY KEY, source_id INTEGER, page INTEGER, text TEXT,
      FOREIGN KEY(source_id) REFERENCES sources(id)
    );
    CREATE TABLE IF NOT EXISTS questions(
      id INTEGER PRIMARY KEY, paper TEXT, module TEXT, topic TEXT, question TEXT,
      a TEXT,b TEXT,c TEXT,d TEXT,answer TEXT,explanation TEXT,
      source_page INTEGER,source_excerpt TEXT, difficulty REAL DEFAULT 0.5
    );
    CREATE TABLE IF NOT EXISTS attempts(
      id INTEGER PRIMARY KEY, question_id INTEGER, selected TEXT, correct INTEGER,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS topic_stats(
      paper TEXT, module TEXT, topic TEXT, seen INTEGER DEFAULT 0, correct INTEGER DEFAULT 0,
      PRIMARY KEY(paper,module,topic)
    );
    """)
    c.commit(); c.close()

init_db()

class AnswerIn(BaseModel):
    question_id: int
    selected: Optional[str]

class GenerateIn(BaseModel):
    paper: str
    module: Optional[str] = None
    count: int = 10

def source_hash(data):
    return hashlib.sha256(data).hexdigest()

def extract_pdf(data: bytes):
    doc = fitz.open(stream=data, filetype="pdf")
    return [(i+1, page.get_text("text")) for i, page in enumerate(doc)]

def update_stats(paper, module, topic, correct):
    c = conn()
    c.execute("""INSERT INTO topic_stats(paper,module,topic,seen,correct) VALUES(?,?,?,?,?)
                 ON CONFLICT(paper,module,topic) DO UPDATE SET
                 seen=seen+1, correct=correct+excluded.correct""",
              (paper,module,topic,1,int(correct)))
    c.commit(); c.close()

def adaptive_module_weights(paper):
    base = SUBJECTS[paper]["weights"]
    c = conn()
    rows = c.execute("SELECT module, seen, correct FROM topic_stats WHERE paper=?", (paper,)).fetchall()
    c.close()
    out = {}
    for m,w in base.items():
        r = next((x for x in rows if x["module"] == m), None)
        if not r or r["seen"] < 3:
            out[m] = w
        else:
            acc = r["correct"]/max(1,r["seen"])
            # Weak modules get more probability; strong modules still appear.
            multiplier = 1.0 + max(0.0, 0.75 - acc) * 1.8
            out[m] = w * multiplier
    total = sum(out.values())
    return {k:v/total for k,v in out.items()}

@app.get("/api/subjects")
def subjects():
    return SUBJECTS

@app.post("/api/upload/{paper}")
async def upload_source(paper: str, file: UploadFile = File(...)):
    if paper not in SUBJECTS:
        raise HTTPException(400, "Unknown paper")
    data = await file.read()
    pages = extract_pdf(data)
    sha = source_hash(data)
    c = conn()
    existing = c.execute("SELECT id FROM sources WHERE sha256=?", (sha,)).fetchone()
    if existing:
        c.close()
        return {"source_id": existing["id"], "status": "already_uploaded"}
    cur = c.execute("INSERT INTO sources(paper,filename,pages,sha256) VALUES(?,?,?,?)",
                    (paper,file.filename,len(pages),sha))
    sid = cur.lastrowid
    for page_no,text in pages:
        if text.strip():
            c.execute("INSERT INTO chunks(source_id,page,text) VALUES(?,?,?)",(sid,page_no,text))
    c.commit(); c.close()
    return {"source_id": sid, "pages": len(pages), "filename": file.filename}

def select_source_chunks(paper, module=None, limit=8):
    c = conn()
    q = """SELECT c.page,c.text FROM chunks c JOIN sources s ON s.id=c.source_id
           WHERE s.paper=? AND length(c.text)>100"""
    params=[paper]
    if module:
        q += " AND c.text LIKE ?"
        params.append(f"%{module}%")
    q += " ORDER BY RANDOM() LIMIT ?"
    params.append(limit)
    rows=c.execute(q,params).fetchall(); c.close()
    return [{"page":r["page"],"text":r["text"][:5000]} for r in rows]

async def llm_generate(paper, chunks, count):
    if not API_KEY or not MODEL:
        raise HTTPException(400, "Set LLM_API_KEY and LLM_MODEL in backend/.env")
    source = "\n\n".join(f"[PAGE {x['page']}]\n{x['text']}" for x in chunks)
    prompt = f"""Create {count} high-quality CMA Foundation MCQs from ONLY the supplied source passages.
Paper: {SUBJECTS[paper]['name']}

Rules:
- Do not use outside knowledge.
- Each question must have exactly 4 options.
- Exactly one option is correct.
- Avoid duplicate questions.
- Include a concise explanation grounded in the source.
- Include source_page and source_excerpt.
- If the passages do not support a question, do not create it.
- Return JSON only:
{{"questions":[{{"module":"Module X","topic":"topic","question":"...",
"a":"...","b":"...","c":"...","d":"...","answer":"A","explanation":"...",
"source_page":1,"source_excerpt":"..."}}]}}
SOURCE:
{source}"""
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(f"{BASE_URL}/chat/completions",
            headers={"Authorization":f"Bearer {API_KEY}","Content-Type":"application/json"},
            json={"model":MODEL,"temperature":0.2,
                  "messages":[{"role":"system","content":"You are a strict source-grounded exam question generator."},
                              {"role":"user","content":prompt}]})
    if r.status_code >= 400:
        raise HTTPException(502, f"LLM error: {r.text[:500]}")
    content=r.json()["choices"][0]["message"]["content"]
    content=content.replace("```json","").replace("```","").strip()
    return json.loads(content)["questions"]

@app.post("/api/generate")
async def generate(req: GenerateIn):
    if req.paper not in SUBJECTS: raise HTTPException(400,"Unknown paper")
    chunks=select_source_chunks(req.paper,req.module,limit=max(8,min(20,req.count*2)))
    if not chunks: raise HTTPException(404,"Upload the corresponding study notes first.")
    qs=await llm_generate(req.paper,chunks,max(1,min(50,req.count)))
    c=conn(); ids=[]
    for q in qs:
        cur=c.execute("""INSERT INTO questions(paper,module,topic,question,a,b,c,d,answer,explanation,source_page,source_excerpt)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(req.paper,q.get("module",""),q.get("topic",""),q["question"],q["a"],q["b"],q["c"],q["d"],
        q["answer"],q.get("explanation",""),q.get("source_page"),q.get("source_excerpt","")))
        ids.append(cur.lastrowid)
    c.commit(); c.close()
    return {"created":len(ids),"question_ids":ids}

def choose_question(paper):
    weights=adaptive_module_weights(paper)
    modules=list(weights.keys()); vals=list(weights.values())
    module=random.choices(modules,weights=vals,k=1)[0]
    c=conn()
    # Prefer unseen / less-accurate questions.
    rows=c.execute("""SELECT q.*,
        COALESCE(ts.seen,0) seen, COALESCE(ts.correct,0) correct
        FROM questions q LEFT JOIN topic_stats ts
        ON ts.paper=q.paper AND ts.module=q.module AND ts.topic=q.topic
        WHERE q.paper=? AND q.module=? ORDER BY RANDOM() LIMIT 30""",(paper,module)).fetchall()
    c.close()
    if not rows:
        return None
    def score(r):
        acc=(r["correct"]/r["seen"]) if r["seen"] else 0.35
        return 1.5-acc + (0.8 if r["seen"]==0 else 0)
    return max(rows,key=score)

@app.get("/api/question/{paper}")
def get_question(paper: str):
    if paper not in SUBJECTS: raise HTTPException(400,"Unknown paper")
    q=choose_question(paper)
    if not q:
        raise HTTPException(404,"No questions yet. Upload notes and generate questions.")
    return {k:q[k] for k in ["id","paper","module","topic","question","a","b","c","d","difficulty"]}

@app.post("/api/answer")
def answer(req: AnswerIn):
    c=conn()
    q=c.execute("SELECT * FROM questions WHERE id=?",(req.question_id,)).fetchone()
    if not q: c.close(); raise HTTPException(404,"Question not found")
    correct = req.selected == q["answer"]
    update_stats(q["paper"],q["module"],q["topic"],correct)
    c.execute("INSERT INTO attempts(question_id,selected,correct) VALUES(?,?,?)",
              (req.question_id,req.selected,int(correct)))
    c.commit(); c.close()
    return {"correct":correct,"answer":q["answer"],"explanation":q["explanation"],
            "source_page":q["source_page"],"source_excerpt":q["source_excerpt"]}

def estimate(paper):
    c=conn()
    rows=c.execute("""SELECT seen,correct FROM topic_stats WHERE paper=?""",(paper,)).fetchall()
    c.close()
    if not rows: return {"estimated_score":None,"confidence":"insufficient data"}
    # Smoothed accuracy prevents a tiny sample from producing extreme predictions.
    seen=sum(r["seen"] for r in rows); correct=sum(r["correct"] for r in rows)
    p=(correct+2)/(seen+4)
    # CMA Foundation papers are commonly treated as 100-mark papers; this is a practice estimate.
    score=round(p*100,1)
    confidence="low" if seen<30 else "medium" if seen<100 else "higher"
    return {"estimated_score":score,"accuracy":round(p*100,1),"attempts":seen,"confidence":confidence}

@app.get("/api/dashboard")
def dashboard():
    result={}
    for p in SUBJECTS:
        result[p]=estimate(p)
    vals=[result[p]["estimated_score"] for p in SUBJECTS if result[p]["estimated_score"] is not None]
    result["overall"]={"estimated_score":round(sum(vals),1) if len(vals)==4 else None,
                       "scale":"out of 400" if len(vals)==4 else "needs data from all four papers"}
    return result

@app.get("/api/mistakes/{paper}")
def mistakes(paper: str):
    c=conn()
    rows=c.execute("""SELECT q.id,q.module,q.topic,q.question,q.a,q.b,q.c,q.d,q.answer,q.explanation,q.source_page,
                      COUNT(*) attempts,SUM(a.correct) wrong_count
                      FROM questions q JOIN attempts a ON a.question_id=q.id
                      WHERE q.paper=? AND a.correct=0
                      GROUP BY q.id ORDER BY wrong_count DESC""",(paper,)).fetchall()
    c.close()
    return [dict(r) for r in rows]

@app.get("/api/topic-stats/{paper}")
def topic_stats(paper: str):
    c=conn()
    rows=c.execute("""SELECT module,topic,seen,correct,
                      ROUND(100.0*correct/NULLIF(seen,0),1) accuracy
                      FROM topic_stats WHERE paper=? ORDER BY accuracy ASC""",(paper,)).fetchall()
    c.close()
    return [dict(r) for r in rows]
